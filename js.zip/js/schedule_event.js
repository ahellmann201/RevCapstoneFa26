import { loadNavbar } from "./navbar.js";
loadNavbar()